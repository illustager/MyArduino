#ifndef MYAUDIO_H
#define MYAUDIO_H

#include <Arduino.h>

#include <XT_DAC_Audio.h>

class myAudio {
public:
	myAudio(byte pin, byte num, const byte **sound_data);
	~myAudio();

	myAudio(const myAudio &other) = delete;
	myAudio &operator=(const myAudio &other) = delete;

	void play(byte select);

private:
	byte playPIN;
	byte num;
	XT_Wav_Class **pSound;
	XT_DAC_Audio_Class *DacAudio;
}; // class myAudio

#endif // MYAUDIO_H
