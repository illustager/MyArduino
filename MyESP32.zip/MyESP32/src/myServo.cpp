#include "myServo.h"

myServo::myServo(byte pin, unsigned minUs = 500, unsigned maxUs = 2500) : pin(pin), minUs(minUs), maxUs(maxUs) {
	this->myservo.setPeriodHertz(50);
	this->myservo.attach(this->pin, this->minUs, this->maxUs); // 舵机连接到指定引脚
};

myServo::~myServo() {
	this->myservo.detach();
}

void myServo::work(int angle) {
	this->myservo.write(angle);
}
