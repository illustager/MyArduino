#include "myAudio.h"

myAudio::myAudio(byte pin, byte num, const byte **sound_data) : playPIN(pin), num(num) {
	DacAudio = new XT_DAC_Audio_Class(playPIN,0);
		
	digitalWrite( playPIN, LOW );

	pSound = new XT_Wav_Class*[num];
	for( int i = 0; i < num; ++i ) 
		pSound[i] = new XT_Wav_Class( sound_data[i] );
}

myAudio::~myAudio() {
	delete DacAudio;
	for( int i = 0; i < num; ++i ) {
		delete pSound[i];
	}
	delete[] pSound;
}

void myAudio::play(byte select) {
	if( num == 0 ) return;

	select %= num;

	DacAudio->Play( pSound[select] );

	while( pSound[select]->Playing ) {
		DacAudio->FillBuffer();
	}

	return;
}
