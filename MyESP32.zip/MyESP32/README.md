# MyESP32

## myIC

### Function

Only for RC522 card reader.

### Dependencies

- Arduino.h

- SPI.h
- MFRC522.h

### Usage

```cpp
#define SS_PIN  12
#define RST_PIN 27

myIC obj(SS_PIN, RST_PIN);

uint32_t data = 0;
while( true ) {
    if( obj.readyet() )
        data = obj.read()
}
```



## myAudio

### Function

Play music.

### Dependencies

- Arduino.h

- XT_DAC_Audio.h

### Usage

```cpp
#define sound_PIN 25

const byte music1[] = { ... };
const byte music2[] = { ... };

const byte* sound_datas[2] = { music1, music2 };

myAudio obj( sound_PIN, 2, sound_datas );

for( int i = 0; i < 2; ++i )
    obj.play( i ); // Blocking while playing
```



## myServo

### Function

Control a servo.

### Dependencies

- Arduino.h
- ESP32Servo.h

### Usage

```cpp
#define servo_PIN 4

myServo obj( servo_PIN, 500, 2500 ); // or just `myServo obj( servo_PIN );`

obj.work( angle );
```



