#ifndef MYTYPE_h 
#define MYTYPE_h 20231129 

namespace mytype {

// int
template <typename T>
struct IsIntegral {
    static const bool value = false;
};

template <>
struct IsIntegral<int> {
    static const bool value = true;
};

template <>
struct IsIntegral<unsigned int> {
    static const bool value = true;
};

template <>
struct IsIntegral<long> {
    static const bool value = true;
};

template <>
struct IsIntegral<unsigned long> {
    static const bool value = true;
};

template <>
struct IsIntegral<long long> {
    static const bool value = true;
};

template <>
struct IsIntegral<unsigned long long> {
    static const bool value = true;
};

template <>
struct IsIntegral<short> {
    static const bool value = true;
};

template <>
struct IsIntegral<unsigned short> {
    static const bool value = true;
};

template <>
struct IsIntegral<char> {
    static const bool value = true;
};

template <>
struct IsIntegral<signed char> {
    static const bool value = true;
};

template <>
struct IsIntegral<unsigned char> {
    static const bool value = true;
};

template <>
struct IsIntegral<bool> {
    static const bool value = true;
};


// char
template <typename T>
struct isChar {
    static const bool value = false;
};

template <>
struct isChar<char> {
    static const bool value = true;
};

template <>
struct isChar<signed char> {
    static const bool value = true;
};

template <>
struct isChar<unsigned char> {
    static const bool value = true;
};

// bool
template <typename T>
struct isBool {
    static const bool value = false;
};

template <>
struct isBool<bool> {
    static const bool value = true;
};

} // namespace mytype

template<typename T>
T myPow( T a, int b )
{
  static_assert( mytype::IsIntegral<T>::value, "InvalidType" );

	T ans = 1;
  while( b ) {
		if( b & 1 )
			ans *= a;
		a *= a;
		b >>= 1;
	}
  return ans;
}

#endif // MYTYPE_h

