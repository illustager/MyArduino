#ifndef MYIO_h 
#define MYIO_h 20231129 

#include <SPI.h>
#include <U8g2lib.h>

#include "mytype.h"

#ifndef MYIO_STEP_X
#define MYIO_STEP_X 6
#endif

#ifndef MYIO_STEP_Y
#define MYIO_STEP_Y 11
#endif

#ifndef MYIO_MAX_X
#define MYIO_MAX_X 120
#endif

#ifndef MYIO_MAX_Y
#define MYIO_MAX_Y 60
#endif

#ifndef MYIO_MIN_X
#define MYIO_MIN_X 0
#endif

#ifndef MYIO_MIN_Y
#define MYIO_MIN_Y MYIO_STEP_Y
#endif

#ifndef MYIO_UNK_CHAR
#define MYIO_UNK_CHAR 32
#endif

#ifndef MYIO_FONT
#define MYIO_FONT u8g2_font_6x10_mr
#endif

namespace myio {

const byte esp32pins[] = { 15, 14, 23, 21, 22 }; 

const char endl[] = "\r\n";

U8G2_SSD1306_128X64_NONAME_F_4W_SW_SPI *pout = NULL;

void (*pfWar)(void) = NULL; // Warning function

void init( const byte *pins=esp32pins, void (*fWar)(void)=NULL )
{
  static  U8G2_SSD1306_128X64_NONAME_F_4W_SW_SPI u8g2(U8G2_R0, 
                                                  /* d0=*/ pins[4],
                                                  /* d1=*/ pins[3], 
                                                  /* cs=*/ pins[0], 
                                                  /* dc=*/ pins[1], 
                                                  /* rs=*/ pins[2]
                                                );

  u8g2.begin();
  u8g2.clearBuffer();
  u8g2.clear();
  u8g2.setFont(MYIO_FONT);
  
  pout = &u8g2;
  pfWar = fWar;
}

bool pageup = false;

void pageUp() {
  pageup = true;
}

char conCh(const char ch, int& x, int& y )
{
  switch( ch ) {
    case '\r':
      x = MYIO_MIN_X; break;

    case '\n':
      y += MYIO_STEP_Y; break;

    case '\b':
      x -= MYIO_STEP_X; break;
    
    case '\f':
      x = MYIO_MIN_X, y = MYIO_MIN_Y; pageUp(); break;

    case '\a':
      if( pfWar != NULL )
        (*pfWar)();
      break;
    
    default:
      return MYIO_UNK_CHAR;
  }
  return 0;
}


bool write(char ch)
{
  
  if( pout == NULL || !ch ) return false;

  static int x = MYIO_MIN_X, y = MYIO_MIN_Y;

  if( ch < 32 || ch == 127 ) {
    ch = conCh( ch, x, y );
  }

  if( x < MYIO_MIN_X ) {
    x = MYIO_MAX_X;
    y -= MYIO_STEP_Y;
  }
  if( y < MYIO_MIN_Y ) {
    x = MYIO_MIN_X, y = MYIO_MIN_Y;
  }
  if( x > MYIO_MAX_X ) {
    x = MYIO_MIN_X, y += MYIO_STEP_Y;
  }
  if( y > MYIO_MAX_Y ) {
    x = MYIO_MIN_X, y = MYIO_STEP_Y;
    pageUp();
  }

  if( ch == 0 ) {
    // Serial.printf( "%d %d %d&\n", ch, x, y );
    return true;
  }

  if( pageup ) {
    // Serial.printf( "%d %d %d?\n", ch, x, y );
    pageup = false;
    pout->clear();
  }

  pout->setCursor( x, y );
  pout->print( ch );

  x += MYIO_STEP_X;

  return true;
}

bool flush()
{
  if( pout == NULL )
    return false;
  pout->sendBuffer();
  return true;
}

bool print(const char* str)
{
  for( int i = 0; i < strlen(str); ++i )
    if( !write( str[i] ) )
      return false;
  
  return flush();
}

bool println(const char* str)
{
  for( int i = 0; i < strlen(str); ++i )
    if( !write( str[i] ) )
      return false;
  
  return print(endl);
}

template<typename T>
bool print(const char* str, T len)
{
  static_assert( mytype::IsIntegral<T>::value, "InvalidType" );

  for( int i = 0; i < len; ++i )
    if( !write( str[i] ) )
      return false;
  
  return flush();
}

template<typename T>
bool println(const char* str, T len)
{
  static_assert( mytype::IsIntegral<T>::value, "InvalidType" );

  for( int i = 0; i < len; ++i )
    if( !write( str[i] ) )
      return false;
  
  return print(endl);
}

template<typename T>
bool print(T num)
{
  static_assert( mytype::IsIntegral<T>::value, "InvalidType" );

  if( mytype::isChar<T>::value ) {
    return write(num) && flush();
  }
  else if( mytype::isBool<T>::value ) {
    return num ? print("True") : print("False");
  }
  else if( num == 0 ) {
    return write(num+'0') && flush();
  }
  
  if( num < 0 )
  {
    if( !write('-') )
      return false;
    num = -num;
  }
  
  T tmp = num;
  int cnt = 0;
  while( num ) {
    ++cnt;
    num /= 10;
  }
  num = tmp;

  for( int i = cnt; i; --i )
  {
    if( !write( (num/myPow<T>(10,i-1))%10 + '0' )  )
      return false;
  }

  return flush();
}

template<typename T>
bool println(T num)
{
  static_assert( mytype::IsIntegral<T>::value, "InvalidType" );

  if( mytype::isChar<T>::value ) {
    return write(num) && print(endl);
  }
  else if( mytype::isBool<T>::value ) {
    return num ? println("True") : println("False");
  }
  else if( num == 0 ) {
    return write(num+'0') && print(endl);
  }
  
  if( num < 0 )
  {
    if( !write('-') )
      return false;
    num = -num;
  }
  
  T tmp = num;
  int cnt = 0;
  while( num ) {
    ++cnt;
    num /= 10;
  }
  num = tmp;

  for( int i = cnt; i; --i )
  {
    if( !write( (num/myPow<T>(10,i-1))%10 + '0' )  )
      return false;
  }

  return flush();
}


} // namespace myio

#endif // MYIO_h

