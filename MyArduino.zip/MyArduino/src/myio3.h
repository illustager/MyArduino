#ifndef MYIO_2_h
#define MYIO_2_h 20240522

#include <SPI.h>
#include <U8g2lib.h>

#include "mytype2.h"

namespace myio {

extern const char *endl;

struct OLEDstreamFontOptions {
	const uint8_t  *font        = u8g2_font_6x10_mr;
	int            minx         = 0;
	int            miny         = 11;
	int            maxx         = 120;
	int            maxy         = 60;
	int            stepx        = 6;
	int            stepy        = 11;
};

class OLEDstream {

private:
	U8G2 *pout;
	byte num;
	int buffsz;
	int minx, miny, maxx, maxy, stepx, stepy;
	void (*fAlarm)();
	char *buffer;

	int nowx, nowy;
	bool is2cls;

public:
	OLEDstream( byte                  num, 
				const byte            *pins,
				int                   buffsz       = 21*5,
				OLEDstreamFontOptions fontopt      = {},
				void                  (*fAlarm)()  = nullptr);

	OLEDstream() = delete;
	OLEDstream(const OLEDstream &other) = delete;
	OLEDstream& operator=(const OLEDstream &other) = delete;

	~OLEDstream();

private:
	char conChr(const char);

	void writeChr(char);
	void writeStr(const char*);

	void printStr(const char* str);
	void printStr(const String& str);

	template <typename T>
	void printNum( T data );

	void pageUp();

public:
	void flush();
	void clear();

	void drawChr(int row, int col, char ch);

	void printf(const char *fmt, ...);

	OLEDstream& operator<<(const char *str);
	OLEDstream& operator<<(const String& str);

	template <typename T>
	OLEDstream& operator<<( T data );

}; // class OLEDstream

template <typename T>
void OLEDstream::printNum( T data )
{
	static_assert( mytype::IsIntegral<T>::value || mytype::IsFloat<T>::value, "[myio2.h]Invalid type of data." );

	if( mytype::IsFloat<T>::value ) {
		this->printf( "%.6lf", (double)data );
		return;
	}
	else if( mytype::IsChar<T>::value ) {
		this->printf( "%c", data );
		return;
	}
	else if( mytype::IsBool<T>::value ) {
		data ? this->printf("True") : this->printf("False");
		return;
	}
	else {
	// Serial.printf("%lld ???\r\n",(long long)data);
		if( data < 0 )
			this->printf( "%lld", (long long)data );
		else
			this->printf( "%llu", (unsigned long long)data );
		return;
	}
}

template <typename T>
OLEDstream& OLEDstream::operator<<( T data )
{
	this->printNum<T>(data);
	return *this;
}


} // namespace myio

#endif // MYIO_2_h
