#include "myio3.h"

namespace myio {

const char *endl = "\r\n\f";

OLEDstream::OLEDstream( byte                  num, 
                        const byte            *pins,
                        int                   buffsz,
                        OLEDstreamFontOptions fontopt,
						void                  (*fAlarm)()
                      ) {
	this->num = num;

	this->buffsz = buffsz;
	this->buffer = new char[buffsz+1];

	this->minx = fontopt.minx;
	this->miny = fontopt.miny;
	this->maxx = fontopt.maxx;
	this->maxy = fontopt.maxy;
	this->stepx = fontopt.stepx;
	this->stepy = fontopt.stepy;
	this->fAlarm = fAlarm;

	this->nowx = fontopt.minx;
	this->nowy = fontopt.miny;

	this->is2cls = false;

	if( num == 7 ) {
	this->pout = new U8G2_SSD1306_128X64_NONAME_F_4W_SW_SPI( U8G2_R0,
														/*d0=*/ pins[0],
														/*d1=*/ pins[1], 
														/*cs=*/ pins[2],
														/*dc=*/ pins[3],
														/*rs=*/ pins[4] );
	}
	else if( num == 6 ) {} // TODO
	else if( num == 4 ) {
	this->pout = new U8G2_SSD1306_128X64_NONAME_F_SW_I2C( U8G2_R0, 
												/*scl=*/  pins[0], 
												/*sda=*/  pins[1] );
	}

	this->pout->begin();
	this->pout->clearBuffer();
	this->pout->clear();
	this->pout->setFont(fontopt.font);
}

OLEDstream::~OLEDstream() {
	delete[] this->buffer;
	delete this->pout;
}

char OLEDstream::conChr( const char ch )
{
	switch( ch ) {
		case '\r':
			this->nowx = this->minx; break;

		case '\n':
			this->nowy += this->stepy; break;

		case '\b':
			this->nowx -= this->stepx; break;

		case '\f':
			this->flush(); break;

		case '\a':
			if( this->fAlarm != NULL )
				(*this->fAlarm)();
			break;

		default:
			return ' '; // TODO
	}
	return 0;
}

void OLEDstream::writeChr(char ch)
{
  // Serial.println((int)ch);

	if( ch < 32 || ch == 127 ) {
		ch = this->conChr( ch );
	}

	if( this->nowx < this->minx ) {
		this->nowx = this->maxx;
		this->nowy -= this->stepy;
	}
	if( this->nowy < this->miny ) {
		this->nowx = this->minx, this->nowy = this->miny;
	}
	if( this->nowx > this->maxx ) {
		this->nowx = this->minx, this->nowy += this->stepy;
	}
	if( this->nowy > this->maxy ) {
		this->nowx = this->minx, this->nowy = this->miny;
		this->pageUp();
	}

	if( ch == 0 ) {
		// Serial.printf( "%d %d %d&\n", ch, this->nowx, this->nowy );
		return;
	}

	if( this->is2cls ) {
		// Serial.printf( "%d %d %d?\n", ch, this->nowx, this->nowy );
		this->is2cls = false;
		this->pout->clear();
	}

	this->pout->setCursor( this->nowx, this->nowy );
	this->pout->print( ch );

	this->nowx += this->stepx;
}

void OLEDstream::writeStr(const char* str)
{
	for( int i = 0; i < strlen(str); ++i )
		this->writeChr( str[i] );
}

void OLEDstream::printf(const char *fmt, ...)
{
	va_list args;

	va_start( args, fmt );

	vsnprintf( this->buffer, this->buffsz, fmt, args );

	// Serial.println( this->buffer );
	this->writeStr( this->buffer );

	va_end( args );

	// this->flush(); // TODO
}

void OLEDstream::printStr(const char *str) {
	this->printf( "%s", str );
}

void OLEDstream::printStr(const String& str) {
	this->printf( "%s", str.c_str() );
}

OLEDstream& OLEDstream::operator<<(const char *str) {
	this->printStr(str);
	return *this;
}

OLEDstream& OLEDstream::operator<<(const String& str) {
	this->printStr(str);
	return *this;
}

void OLEDstream::pageUp() {
	this->is2cls = true;
}

void OLEDstream::flush() {
	this->pout->sendBuffer();
}

void OLEDstream::clear() {
	this->nowx = this->minx;
	this->nowy = this->miny;
	
	this->pout->clear();
}

void OLEDstream::drawChr(int row, int col, char ch) {
	int x = this->minx + col * this->stepx;
	int y = this->miny + row * this->stepy;
	this->pout->setCursor( x, y );
	this->pout->print( ch );
	this->pout->setCursor( this->nowx, this->nowy );
}

} // namespace myio
