#ifndef MYIO_2_h
#define MYIO_2_h 20231204

#include <SPI.h>
#include <U8g2lib.h>

#include "mytype2.h"

namespace myio {

const char *endl = "\r\n";
const char *clear = "\f";
const char *cls = clear; // 兼容旧版
const char *alarm = "\a";

String errors[] = { 
  "ERROR(0) in myio2.h" // 禁止 OLEDstream 实例之间赋值
};

struct OLEDstreamFontOptions {
  const uint8_t  *font        = u8g2_font_6x10_mr;
  int            minx         = 0;
  int            miny         = 11;
  int            maxx         = 120;
  int            maxy         = 60;
  int            stepx        = 6;
  int            stepy        = 11;
};

class OLEDstream {

private:
  U8G2 *pout;
  byte num;
  int buffsz;
  int minx, miny, maxx, maxy, stepx, stepy;
  void (*fAlarm)();
  char *buffer;

  int nowx, nowy;
  bool is2cls;

public:
  OLEDstream( byte num, 
              const byte *pins,
              void (*fAlarm)(),
              int buffsz,
              OLEDstreamFontOptions fontopt );
  
  OLEDstream(OLEDstream &obj);
  
  ~OLEDstream() {
    if( this->pout )
      delete this->pout;
    if( this->buffer )
      delete[] this->buffer;
  }

private:
  char conChr(const char);

  void writeChr(char);
  void writeStr(const char*);

  void printStr(const char* str);
  void printStr(const String& str);

  template <typename T>
  void printNum( T data );

  void flush() {
    this->pout->sendBuffer();
  }

  void pageUp() {
    this->is2cls = true;
  }

public:
  void printf(const char *fmt, ...);

  OLEDstream& operator<<(const char *str);
  OLEDstream& operator<<(const String& str);

  template <typename T>
  OLEDstream& operator<<( T data );

}; // class OLEDstream

OLEDstream::OLEDstream( byte                  num, 
                        const byte            *pins,
                        void                  (*fAlarm)()  = NULL,
                        int                   buffsz       = 21*5,
                        OLEDstreamFontOptions fontopt      = {}
                      ) {
  this->num = num;

  this->buffsz = buffsz;
  this->buffer = new char[buffsz+1];

  this->minx = fontopt.minx;
  this->miny = fontopt.miny;
  this->maxx = fontopt.maxx;
  this->maxy = fontopt.maxy;
  this->stepx = fontopt.stepx;
  this->stepy = fontopt.stepy;
  this->fAlarm = fAlarm;

  this->nowx = fontopt.minx;
  this->nowy = fontopt.miny;

  this->is2cls = false;

  if( num == 7 ) {
    this->pout = new U8G2_SSD1306_128X64_NONAME_F_4W_SW_SPI( U8G2_R0,
                                                     /*d0=*/ pins[0],
                                                     /*d1=*/ pins[1], 
                                                     /*cs=*/ pins[2],
                                                     /*dc=*/ pins[3],
                                                     /*rs=*/ pins[4] );
  }
  else if( num == 6 ) {} // TODO
  else if( num == 4 ) {
    this->pout = new U8G2_SSD1306_128X64_NONAME_F_SW_I2C( U8G2_R0, 
                                                /*scl=*/  pins[0], 
                                                /*sda=*/  pins[1] );
  }
  
  this->pout->begin();
  this->pout->clearBuffer();
  this->pout->clear();
  this->pout->setFont(fontopt.font);
}

OLEDstream::OLEDstream(OLEDstream &obj) {
  obj << cls << errors[0]; // TODO
  
  while(true){};
}

char OLEDstream::conChr( const char ch )
{
  switch( ch ) {
    case '\r':
      this->nowx = this->minx; break;

    case '\n':
      this->nowy += this->stepy; break;

    case '\b':
      this->nowx -= this->stepx; break;
    
    case '\f':
      this->nowx = this->minx, this->nowy = this->miny; this->pageUp(); break;

    case '\a':
      if( this->fAlarm != NULL )
        (*this->fAlarm)();
      break;
    
    default:
      return ' '; // TODO
  }
  return 0;
}

void OLEDstream::writeChr(char ch)
{
  // Serial.println((int)ch);

  if( ch < 32 || ch == 127 ) {
    ch = this->conChr( ch );
  }

  if( this->nowx < this->minx ) {
    this->nowx = this->maxx;
    this->nowy -= this->stepy;
  }
  if( this->nowy < this->miny ) {
    this->nowx = this->minx, this->nowy = this->miny;
  }
  if( this->nowx > this->maxx ) {
    this->nowx = this->minx, this->nowy += this->stepy;
  }
  if( this->nowy > this->maxy ) {
    this->nowx = this->minx, this->nowy = this->stepy;
    this->pageUp();
  }

  if( ch == 0 ) {
    // Serial.printf( "%d %d %d&\n", ch, this->nowx, this->nowy );
    return;
  }

  if( this->is2cls ) {
    // Serial.printf( "%d %d %d?\n", ch, this->nowx, this->nowy );
    this->is2cls = false;
    this->pout->clear();
  }

  this->pout->setCursor( this->nowx, this->nowy );
  this->pout->print( ch );

  this->nowx += this->stepx;
}

void OLEDstream::writeStr(const char* str)
{
  for( int i = 0; i < strlen(str); ++i )
    this->writeChr( str[i] );
}

void OLEDstream::printf(const char *fmt, ...)
{
  va_list args;

  va_start( args, fmt );

  vsnprintf( this->buffer, this->buffsz, fmt, args );

  // Serial.println( this->buffer );
  this->writeStr( this->buffer );

  va_end( args );

  this->flush(); // TODO
}

void OLEDstream::printStr(const char *str) {
  this->printf( "%s", str );
}

void OLEDstream::printStr(const String& str) {
  this->printf( "%s", str.c_str() );
}

template <typename T>
void OLEDstream::printNum( T data )
{
  static_assert( mytype::IsIntegral<T>::value || mytype::IsFloat<T>::value, "[myio2.h]Invalid type of data." );

  if( mytype::IsFloat<T>::value ) {
    this->printf( "%.6lf", (double)data );
    return;
  }

  else if( mytype::IsChar<T>::value ) {
    this->printf( "%c", data );
    return;
  }
  else if( mytype::IsBool<T>::value ) {
    data ? this->printf("True") : this->printf("False");
    return;
  }
  else {
    // Serial.printf("%lld ???\r\n",(long long)data);
    if( data < 0 )
      this->printf( "%lld", (long long)data );
    else
      this->printf( "%llu", (unsigned long long)data );
    return;
  }
}

OLEDstream& OLEDstream::operator<<(const char *str) {
  this->printStr(str);
  return *this;
}

OLEDstream& OLEDstream::operator<<(const String& str) {
  this->printStr(str);
  return *this;
}

template <typename T>
OLEDstream& OLEDstream::operator<<( T data )
{
  this->printNum<T>(data);
  return *this;
}

} // namespace myio

#endif // MYIO_2_h
