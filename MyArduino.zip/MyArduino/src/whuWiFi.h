#ifndef WHUWIFI_h
#define WHUWIFI_h 20231129

#include <HTTPClient.h>
#include <ArduinoJson.h>

namespace whu {

const String headers[][2] = {
  {"Host","172.19.1.9:8080"},
  {"Content-Type","application/x-www-form-urlencoded; charset=UTF-8"},
  {"Content-Length","676"},
  {"Connection","close"},
  {"Origin","http://172.19.1.9:8080"},
  {"Referer","http://172.19.1.9:8080/eportal/index.jsp?wlanuserip=ad1052f9d875d2c2688e2f96843707e3&wlanacname=29185648f4390d794a0cec29fdffd6ef&ssid=&nasip=07e38f2323f330cd5ffcc3a203a63100&snmpagentip=&mac=c66a5d88ab865b984ddc3cf60d3f7684&t=wireless-v2&url=096e8e7059e430e05980c3c547fed4ab7ccaeae90dfffda4ace4874ac81c5ad69031883e2cfd5141&apmac=&nasid=29185648f4390d794a0cec29fdffd6ef&vid=4a271faa0aa0da72&port=43a157a1d4e962c7&nasportid=ac41d60d7f1382081362a1ed29e6af27f8be24a7bb56d0d19c3342ac86d029f5"},
};
const byte hCnt = 6;

const String others = "&service=Internet&queryString=wlanuserip%253Dad1052f9d875d2c2688e2f96843707e3%2526wlanacname%253D29185648f4390d794a0cec29fdffd6ef%2526ssid%253D%2526nasip%253D07e38f2323f330cd5ffcc3a203a63100%2526snmpagentip%253D%2526mac%253Dc66a5d88ab865b984ddc3cf60d3f7684%2526t%253Dwireless-v2%2526url%253D096e8e7059e430e05980c3c547fed4ab7ccaeae90dfffda4ace4874ac81c5ad69031883e2cfd5141%2526apmac%253D%2526nasid%253D29185648f4390d794a0cec29fdffd6ef%2526vid%253D4a271faa0aa0da72%2526port%253D43a157a1d4e962c7%2526nasportid%253Dac41d60d7f1382081362a1ed29e6af27f8be24a7bb56d0d19c3342ac86d029f5&operatorPwd=&operatorUserId=&validcode=&passwordEncrypt=";

const String url = "http://172.19.1.9:8080/eportal/InterFace.do?method=login";

String msg = "";

bool login(const String& userId, const String& password, String& message=msg)
{
  String request = "userId=" + userId + "&password=" + password + others;

  HTTPClient http;
  http.begin(url);

  for( int i = 0; i < hCnt; ++i )
    http.addHeader( headers[i][0], headers[i][1] );

  if( http.POST( request ) > 0 ) {
    DynamicJsonDocument response(500);
    deserializeJson(response, http.getString());
    // Serial.println( response["message"].as<String>() );
    message = response["message"].as<String>();
    return response["result"].as<String>() == "success";
  }
  else
    return false;
    
}

} // namespace whu

#endif // WHUWIFI_h
