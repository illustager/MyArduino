#ifndef MYTYPE_2_h
#define MYTYPE_2_h 20231204

namespace mytype {

// int
template <typename T>
struct IsIntegral {
    static const bool value = false;
};

// template <>
// struct IsIntegral<int> {
//     static const bool value = true;
// };

template <>
struct IsIntegral<signed int> {
    static const bool value = true;
};

template <>
struct IsIntegral<unsigned int> {
    static const bool value = true;
};

// template <>
// struct IsIntegral<long> {
//     static const bool value = true;
// };

template <>
struct IsIntegral<signed long> {
    static const bool value = true;
};

template <>
struct IsIntegral<unsigned long> {
    static const bool value = true;
};

// template <>
// struct IsIntegral<long long> {
//     static const bool value = true;
// };

template <>
struct IsIntegral<signed long long> {
    static const bool value = true;
};

template <>
struct IsIntegral<unsigned long long> {
    static const bool value = true;
};

// template <>
// struct IsIntegral<short> {
//     static const bool value = true;
// };

template <>
struct IsIntegral<signed short> {
    static const bool value = true;
};

template <>
struct IsIntegral<unsigned short> {
    static const bool value = true;
};

template <>
struct IsIntegral<char> {
    static const bool value = true;
};

template <>
struct IsIntegral<signed char> {
    static const bool value = true;
};

template <>
struct IsIntegral<unsigned char> {
    static const bool value = true;
};

template <>
struct IsIntegral<bool> {
    static const bool value = true;
};

// char
template <typename T>
struct IsChar {
    static const bool value = false;
};

template <>
struct IsChar<char> {
    static const bool value = true;
};

template <>
struct IsChar<signed char> {
    static const bool value = true;
};

template <>
struct IsChar<unsigned char> {
    static const bool value = true;
};

// bool
template <typename T>
struct IsBool {
    static const bool value = false;
};

template <>
struct IsBool<bool> {
    static const bool value = true;
};

// float
template <typename T>
struct IsFloat {
    static const bool value = false;
};

template <>
struct IsFloat<float> {
    static const bool value = true;
};

template <>
struct IsFloat<double> {
    static const bool value = true;
};

template <>
struct IsFloat<long double> {
    static const bool value = true;
};

} // namespace mytype

#endif // MYTYPE_2_h
