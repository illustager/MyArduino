# MyArduino



## 网络模块

### whuWiFi.h

#### whu::login()

在已连接武大 WiFi 的前提下，登录武大校园网。

函数原型：

```cpp
bool whu::login( const String& ssid,   // 用户名
                 const String& pwd,    // 密码
                 String& message = msg // 获取登录失败后的消息，默认存储在 whu::msg 中
               );
```

登录成功返回`true`，反之则返回`false`。若未指明第三个参数，则失败后的消息存储在`String whu::msg` 中。

**例程**

```c++
#include <whuWiFi.h>

void setup() {

  Serial.begin(9600);

  connectWiFi( "WHU-STU", "" ); // 连接 WiFi 自行实现
  
  bool res = whu::login( "2023302121xxx", "xxxxxx" );
  if( !res )
    Serial.println(whu::msg);
    
  Serial.println( res );

}

void loop() {}
```



## I/O模块

### myio.h

已弃用。

### mytype.h

为`myio.h`提供断言`template`的方法，已弃用。

### myio2.h

已弃用

### mytype2.h

为 `myio2.h` 和 `myio3,h` 提供断言`template`的方法

### myio3.h

```cpp
namespace myio {

extern const char *endl;
extern const char *alarm;

struct OLEDstreamFontOptions {
	const uint8_t  *font        = u8g2_font_6x10_mr;
	int            minx         = 0;
	int            miny         = 11;
	int            maxx         = 120;
	int            maxy         = 60;
	int            stepx        = 6;
	int            stepy        = 11;
};

class OLEDstream {
public:
	OLEDstream( byte                  num, 
				const byte            *pins,
				int                   buffsz       = 21*5,
				OLEDstreamFontOptions fontopt      = {},
				void                  (*fAlarm)()  = nullptr);

	OLEDstream() = delete;
	OLEDstream(const OLEDstream &other) = delete;
	OLEDstream& operator=(const OLEDstream &other) = delete;

	~OLEDstream();

public:
	void flush();
	void clear();

	void drawChr(int row, int col, char ch);

	void printf(const char *fmt, ...);

	OLEDstream& operator<<(const char *str);
	OLEDstream& operator<<(const String& str);

	template <typename T>
	OLEDstream& operator<<( T data );

private:
    // something private
    
}; // class OLEDstream

} // namespace myio
```

例程

```cpp
#include <myio3.h>

using namespace myio;

// const byte outpins[] = { 22, 21, 15, 14, 23 };
const byte outpins[] = { 22, 21 };

OLEDstream myout( 4, outpins );

void setup() {
	myout.printf( "A num: %d\r\nA char: %c\r\nA string: %s\r\nA hex: %x\r\nA float: %.2f\r\n", 5, 'a', "aaaa", 89, 3.1415927 );
	myout.flush();

	delay(2000);

	myout << 5 << endl
          << 'a' << endl
          << "aaaa" << endl
          << 5.6 << endl;
	myout.flush();
	
	delay(2000);

	myout.drawChr( 3, 1, 'x' );
	myout.flush();

	delay(2000);

	myout << "Hello, world!" << endl;
	myout.flush();

	delay(2000);

	myout.clear();
}

void loop() {}
```



